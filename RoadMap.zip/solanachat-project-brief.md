# SolanaChat — Project Brief (Claude Project knowledge file)

Paste this into a new Claude Project named "Solana-Chat" — either as the project's custom instructions, or upload as a knowledge file. See setup steps at the bottom.

## What this project is
SolanaChat is an AI-powered natural language transaction interface for Solana, built by Nessi. It placed 2nd at a hackathon in Ethiopia and is now in the Dev3pack Bridge accelerator (dev3pack.xyz), working toward a Colosseum-track funding pitch. 7 weeks remain in the 8-week Bridge program.

**Core stack:** Next.js 16, React 19, Solana Web3.js + SPL Token, custom SBF program on devnet (`4Eh646fwA4q1G6xAtSXUYTzrAvHRZJ5MsZvmBmLBWuUK`, 6 instructions: InitVault, Deposit, ExecuteDca, CloseVault, InitTimelock, ClaimTimelock), Jupiter Swap API v6, Anthropic Claude for intent parsing, Phantom Wallet Adapter, optional ElevenLabs voice confirmation.

**Current feature surface (built, possibly over-scoped):** natural-language send/swap, DCA vaults (recurring payments), timelocked transfers, voice confirmation before signing, Explorer links, vault/timelock sidebar.

## Where the project stands strategically
Built fast, shipped a lot of features, but features were added before real user validation. Current focus: retroactively validate the problem, narrow to one wedge use case, instrument the product for real usage data, then use that data for the Bridge demo day pitch and funding push.

## 7-week roadmap (current)
- Week 1 — Validate: run 15–20 user interviews (script below), find the strongest pain point and who feels it most.
- Week 2 — Reposition: cut scope to one core wedge use case; rewrite the pitch around it.
- Week 3 — Instrument: add lightweight usage analytics, get real testers on devnet.
- Weeks 4–7 — Iterate and pitch: use real usage data to sharpen the deck, roadmap, and funding narrative; target Colosseum-style application.

## Competitive/ecosystem context (as of mid-2026)
- Phantom ships an MCP server for AI agents — the "AI chat layer on top of a wallet" idea alone is not strongly differentiated.
- A growing field of multi-chain agentic AI wallets exists (non-custodial, broad chain coverage).
- Solana's recurring/locked-payment primitives (DCA, vesting, scheduled transfers) are comparatively underbuilt versus one-off swap tooling — this is the more defensible angle for SolanaChat versus "AI chatbot for crypto."
- Likely strongest underserved segment: non-technical or emerging-market users who want recurring/locked transfers without touching a DEX UI directly (relevant to Nessi's Ethiopia/diaspora-remittance context).

## Solana ecosystem communities for user research, distribution, and feedback
- **Superteam (global + regional chapters)** — gated Discord network of builders/talent across ~10+ countries; Superteam Nigeria is the most active African chapter (discord.gg/SRCBxhHv) and a good proxy community for emerging-market Solana users even without an Ethiopia-specific chapter yet.
- **Official Solana Discord** ("Solana Tech") — developer-help and ecosystem channels; ~140k+ members, active EU/US daytime hours.
- **Solana Telegram (official)** — ~70k members, announcements-focused, lower for deep discussion.
- **Dev3pack / Bridge network** — your own cohort, plus partner communities like Sol Sisters; Telegram at t.me/sdaav.
- **Colosseum community** — hackathon/accelerator-adjacent builder network, relevant given the Bridge's framing as a path into Colosseum.
- **Jupiter community channels** — useful if positioning near swap/DeFi-intent users.
- **X (Twitter) Solana dev circle** — less structured but high-signal; many Superteam/Colosseum builders post there first.

Caution: avoid generic "Solana trading/sniper" Discords for user research — they skew toward memecoin traders, not the recurring-payment/remittance segment most relevant to SolanaChat's wedge.

## How to use this project
- Drop interview notes, deck drafts, and analytics summaries into this project's knowledge as you go.
- Ask Claude inside this project to update the pitch deck, re-cut the roadmap, or analyze interview themes — it will have this context automatically.

---

## Setting up the actual Claude Project (manual steps, Claude can't create it for you)
1. Go to claude.ai/projects and click "+ New Project."
2. Name it `Solana-Chat`.
3. Click "Set project instructions" and paste the sections above (or a trimmed version) in.
4. Upload this file, your README, your pitch deck, and interview notes as project knowledge — Claude will reference them automatically in every chat inside the project.
