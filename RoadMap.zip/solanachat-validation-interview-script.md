# SolanaChat — User Validation Interview Script

**Goal:** find out if the problem is real and who feels it most, before pitching the solution.
**Rule:** ask about things they've actually done, not what they'd hypothetically do. If you catch yourself describing SolanaChat in the first 10 minutes, stop — you're leading them.
**Length:** 20–25 minutes. Record with permission, or take notes live.

---

## 1. Warm-up (2 min)
- "Thanks for making time. I'm not selling anything today — I'm trying to understand how people actually move money or tokens on Solana, so anything you tell me helps."
- "Quick context: what's your role/relationship to crypto — builder, trader, treasury manager, someone who sends money to family, etc.?"

## 2. Current behavior (8 min) — the most important section
- "Walk me through the last time you sent SOL or a token to someone else. What did you use, step by step?"
- "How often do you do that — sending to the same person or place repeatedly?"
- "Have you ever needed to send something on a schedule (weekly, monthly) or release funds at a future date? How did you handle that — manually, a tool, a reminder?"
- "What's the most annoying part of that whole process?"
- "Has a mistake ever happened — wrong address, wrong amount, wrong network? What happened next?"
- "What do you currently use for swaps? Walk me through the last swap you did."

## 3. Pain ranking (3 min)
- "Of everything you just described, what's the single most annoying or riskiest part?"
- "On a scale of 'mildly annoying' to 'I actively avoid doing this because of it' — where does that land?"
- "Have you tried to fix it yourself — a script, a spreadsheet, a bot, asking someone else to handle it?"

## 4. Money / commitment test (3 min) — skip vague hypotheticals
- "Have you ever paid for a tool, bot, or service to make this easier? What was it, what did it cost?"
- "If something solved [the specific pain they named] today, who in your life or work would also need it?"

## 5. Light concept check (3 min) — only after sections 1–4
- "I've been building something — you send a message like 'send 5 USDC to Alice every week' and it sets that up on-chain automatically, with a voice readback before you sign. Does that map to a real moment in what you just described, or does it not really apply to you?"
- "What would make you *not* trust something like that?"
- "Would you want this as a wallet feature, a browser extension, a Telegram bot, or something else? Why?"

## 6. Close (1 min)
- "Can I follow up in 2–3 weeks with an early version for you to try on devnet?"
- "Anyone else you know who'd be useful for me to talk to?"

---

## After each interview — log immediately
- Exact quote for the strongest pain point (verbatim, not your summary)
- Their current workaround (free text)
- Did they bring up DCA/recurring payments unprompted? Y/N
- Did they bring up timelocks/scheduled release unprompted? Y/N
- Would-pay signal: none / maybe / already pays for something similar
- Segment tag: builder / trader / remitter / DAO-treasury / creator / other

## Target mix for 15–20 interviews
- 5–7 people who send recurring/repeat payments (remittance, payroll, subscriptions)
- 5–7 active Solana traders/swappers
- 3–5 DAO contributors or treasury operators
- 2–3 total non-crypto-native people (gut check on the "no blockchain knowledge required" claim)
